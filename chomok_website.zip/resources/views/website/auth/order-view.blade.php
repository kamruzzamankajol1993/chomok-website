@extends('website.master.master')
@section('title', 'Order '.$order->order_number.' | '.($siteSetting?->restaurant_name ?? 'Chomok'))
@section('body')
<section class="dashboard-section">
  <div class="menu-section-head"><span class="badge-text">Order Details</span><h1 class="menu-section-title">{{ $order->order_number }}</h1></div>
  <div class="checkout-summary mx-auto" style="max-width:850px">
    <div class="checkout-total-row"><span>Order Type</span><strong>{{ $order->order_type_label }}</strong></div>
    <div class="checkout-total-row"><span>Status</span><strong>{{ ucfirst($order->status) }}</strong></div>
    <div class="checkout-total-row"><span>Branch</span><strong>{{ $order->branch?->name }}</strong></div>
    <div class="checkout-total-row"><span>Placed</span><strong>{{ $order->created_at?->format('d/m/Y h:i A') }}</strong></div>
    @if($order->delivery_address)<div class="checkout-total-row"><span>Delivery Address</span><strong>{{ $order->delivery_address }}</strong></div>@endif
    @foreach($order->items as $item)
      <div class="checkout-item">
        <div class="checkout-item-info">
          <h4>{{ $item->item_name }}</h4>
          <span>{{ $item->size_label }} × {{ $item->quantity }}</span>
          @if(str_starts_with((string) $item->note, 'BOGO FREE:'))
            <small class="d-block mt-1 fw-bold">🎁 FREE ITEM — same variation/size, add-ons and options as the paid item.</small>
          @endif
          @if($item->addons->isNotEmpty())
            <div class="mt-1">
            @foreach($item->addons as $addon)
              @php($addonDescription = $addon->description ?: $addon->menuItemPriceAddon?->description ?: $addon->addon?->description)
              <small class="d-block"><strong>{{ $addon->addon_name }}</strong>@if(filled($addonDescription))<span class="d-block text-muted">{{ $addonDescription }}</span>@endif</small>
            @endforeach
            </div>
          @endif
        </div>
        <span class="checkout-item-price">TK {{ rtrim(rtrim(number_format((float)$item->line_total,2,'.',''),'0'),'.') }}</span>
      </div>
    @endforeach
    <div class="checkout-totals">
      <div class="checkout-total-row"><span>Subtotal</span><span>TK {{ rtrim(rtrim(number_format((float)$order->subtotal,2,'.',''),'0'),'.') }}</span></div>
      @if((float)$order->discount > 0)<div class="checkout-total-row"><span>Discount</span><span>- TK {{ rtrim(rtrim(number_format((float)$order->discount,2,'.',''),'0'),'.') }}</span></div>@endif
      @if((float)$order->tax_rate > 0)<div class="checkout-total-row"><span>{{ $order->tax_label ?: 'VAT' }} ({{ rtrim(rtrim(number_format((float)$order->tax_rate,2,'.',''),'0'),'.') }}%)</span><span>TK {{ rtrim(rtrim(number_format((float)$order->tax_amount,2,'.',''),'0'),'.') }}</span></div>@endif
      @if((float)$order->delivery_charge > 0)<div class="checkout-total-row"><span>Delivery Fee</span><span>TK {{ rtrim(rtrim(number_format((float)$order->delivery_charge,2,'.',''),'0'),'.') }}</span></div>@endif
      <div class="checkout-total-row checkout-total-final"><span>Total</span><span>TK {{ rtrim(rtrim(number_format((float)$order->grand_total,2,'.',''),'0'),'.') }}</span></div>
    </div>
    <a href="{{ route('client.dashboard') }}" class="btn-wc-hero">Back to Dashboard</a>
  </div>
</section>
@endsection
